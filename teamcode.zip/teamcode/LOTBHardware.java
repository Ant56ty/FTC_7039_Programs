package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.TFObjectDetector;

public class LOTBHardware {

    public DcMotor Right_Bottom;
    public DcMotor Right_Top;
    public DcMotor Left_Bottom;
    public DcMotor Left_Top;
    public DcMotor Sweeper;
    public DcMotor Lift;
    public DcMotor Dumpee;

    public ColorSensor colorSensor;

    public Servo Dumper;



    public double Move_Forward = .3;
    public double Move_Backward = -.3;

    public VuforiaLocalizer vuforia;


    public TFObjectDetector tfod;


    HardwareMap hwMap = null;
    private ElapsedTime period = new ElapsedTime();

    /* Constructor */
    public LOTBHardware() {
    }

    /* Initialize standard Hardware interfaces */
    public void init(HardwareMap ahwMap) {
        // save reference to HW Map
        hwMap = ahwMap;

        Right_Bottom = hwMap.get(DcMotor.class, "Right_Bottom");
        Right_Top = hwMap.get(DcMotor.class, "Right_Top");
        Left_Bottom = hwMap.get(DcMotor.class, "Left_Bottom");
        Left_Top = hwMap.get(DcMotor.class, "Left_Top");
        Sweeper = hwMap.get(DcMotor.class, "Sweeper");
        Lift = hwMap.get(DcMotor.class, "Lift");
        Dumpee = hwMap.get(DcMotor.class, "Dumpee");

        colorSensor = hwMap.get(ColorSensor.class, "Color_Sensor");

        Dumper = hwMap.get(Servo.class, "Dumper");

        Left_Top.setDirection(DcMotor.Direction.REVERSE);
        Left_Bottom.setDirection(DcMotor.Direction.REVERSE);

        Right_Bottom.setPower(0);
        Right_Top.setPower(0);
        Left_Bottom.setPower(0);
        Left_Top.setPower(0);
        Sweeper.setPower(0);
    }

    /*public void GoToCoordinates(int Coordinates){
           //String CRD = Double.toString(Coordinates);
           Right_Bottom.setTargetPosition(Coordinates);
           Left_Top.setTargetPosition(Coordinates);
           Left_Bottom.setTargetPosition(Coordinates);
           Right_Top.setTargetPosition(Coordinates);
    }*/

}
