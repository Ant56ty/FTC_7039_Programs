package org.firstinspires.ftc.teamcode;

import android.graphics.Color;

import com.qualcomm.hardware.rev.RevBlinkinLedDriver;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@TeleOp(name = "NewTeleop")
public class NewLordOfTheBricksTeleop extends LinearOpMode
{
    LOTBHardware robot = new LOTBHardware();
    public static int Move_Forward = 1;
    public static int Move_Backward = -1;

    RevBlinkinLedDriver blinkinLedDriver;
    RevBlinkinLedDriver.BlinkinPattern patternSM;
    RevBlinkinLedDriver.BlinkinPattern patternGM;

    Telemetry.Item patternName;
    Telemetry.Item display;
    Blinky.DisplayKind displayKind;

    @Override
    public void runOpMode() throws InterruptedException{
        displayKind = Blinky.DisplayKind.AUTO;
        patternSM = RevBlinkinLedDriver.BlinkinPattern.BLUE;
        patternGM = RevBlinkinLedDriver.BlinkinPattern.YELLOW;
        robot.init(hardwareMap);
        waitForStart();

        while (opModeIsActive()){



            // This is for reading in both color/ distance sensors
        if ((robot.RightDistanceSensor.getDistance(DistanceUnit.INCH)) <= 2 && (robot.LeftDistanceSensor.getDistance(DistanceUnit.INCH)) <= 2) {

            if (robot.RightDistanceSensor.equals(Color.YELLOW) && robot.LeftDistanceSensor.equals(Color.YELLOW)) {
                telemetry.addData("Color", "All Yellow");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.YELLOW);
            } else if (robot.RightDistanceSensor.equals(Color.YELLOW) && robot.LeftDistanceSensor.equals(Color.WHITE)) {
                telemetry.addData("Color", "Right Yellow, Left White");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.CONFETTI);
            } else if (robot.RightDistanceSensor.equals(Color.WHITE) && robot.LeftDistanceSensor.equals(Color.YELLOW)) {
                telemetry.addData("Color", "Right White, Left Yellow");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.LAWN_GREEN);
            } else if (robot.RightDistanceSensor.equals(Color.WHITE) && robot.LeftDistanceSensor.equals(Color.WHITE)) {
                telemetry.addData("Color", "All White");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.BLUE);
            }

        }
            // This is for reading the right color sensor
        else if ((robot.RightDistanceSensor.getDistance(DistanceUnit.INCH)) <= 2) {

            if (robot.RightDistanceSensor.equals(Color.YELLOW)) {
                telemetry.addData("Color Right", "Yellow");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.BLACK);
            } else if (robot.RightDistanceSensor.equals(Color.WHITE)) {
                telemetry.addData("Color Right", "White");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.BEATS_PER_MINUTE_OCEAN_PALETTE);
            }
        }
        // This is for reading the left color sensor
        else if ((robot.LeftDistanceSensor.getDistance(DistanceUnit.INCH)) <= 2) {

            if (robot.LeftDistanceSensor.equals(Color.YELLOW)) {
                telemetry.addData("Color Left", "Yellow");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.BEATS_PER_MINUTE_FOREST_PALETTE);
            } else if (robot.LeftDistanceSensor.equals(Color.WHITE)) {
                telemetry.addData("Color Left", "White");
                telemetry.update();
                robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.BREATH_RED);
            }
        }
        // This is for reading No Minerals
        else {
            telemetry.addData("No Minerals", "Still No Minerals!!!!!");
            telemetry.update();
            robot.Blinky.setPattern(RevBlinkinLedDriver.BlinkinPattern.ORANGE);
        }

            /*if (robot.RightColorSensor.equals(Color.YELLOW)) {
                telemetry.addData("Color", "Yellow");
                telemetry.update();
                robot.Blinky.setPattern(patternGM);
            }

            else if (robot.RightColorSensor.equals(Color.WHITE)) {
                    telemetry.addData("Color", "White");
                    telemetry.update();
                    robot.Blinky.setPattern(patternSM);
            }

            if (robot.LeftColorSensor.equals(Color.YELLOW)) {
                telemetry.addData("Color", "Yellow");
                telemetry.update();
                robot.Blinky.setPattern(patternGM);
            }

            else if (robot.LeftColorSensor.equals(Color.WHITE)) {
                telemetry.addData("Color", "White");
                telemetry.update();
                robot.Blinky.setPattern(patternSM);
            }*/


            robot.Right_Top.setPower(-gamepad1.right_stick_y);
            robot.Right_Bottom.setPower(-gamepad1.right_stick_y);
            robot.Left_Top.setPower(-gamepad1.left_stick_y);
            robot.Left_Bottom.setPower(-gamepad1.left_stick_y);
            // robot.Conveyor.setPower(.5);
            /*while (gamepad1.right_stick_x == 1){
                robot.Right_Top.setPower(.3);
                robot.Right_Bottom.setPower(.3);
            }

            while (gamepad1.left_stick_x == 1){
                robot.Left_Top.setPower(.3);
                robot.Left_Bottom.setPower(.3);
            }

            while (gamepad1.left_stick_x == -1){
                robot.Left_Bottom.setPower(.3);
                robot.Left_Top.setPower(.3);
            }

            while (gamepad1.right_stick_x == -1){
                robot.Right_Top.setPower(.3);
                robot.Right_Bottom.setPower(.3);
            }

            while (gamepad1.left_stick_button){
                robot.Left_Bottom.setPower(-.3);
                robot.Left_Top.setPower(.3);
                robot.Right_Top.setPower(-.3);
                robot.Right_Bottom.setPower(.3);
            }

            while (gamepad1.right_stick_button){
                robot.Left_Bottom.setPower(.3);
                robot.Left_Top.setPower(-.3);
                robot.Right_Bottom.setPower(-.3);
                robot.Right_Top.setPower(.3);
            }*/



            while (gamepad1.right_stick_x == 1 && gamepad1.right_stick_y == 1){
                robot.Right_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Top.setPower(.6);
                robot.Right_Bottom.setPower(.6);
            } while(gamepad1.right_stick_y == -1 && gamepad1.right_stick_x == -1) {
                robot.Right_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Top.setPower(-.6);
                robot.Right_Bottom.setPower(-.6);
            } while (gamepad1.left_stick_x == 1 && gamepad1.right_stick_y == 1){
                robot.Right_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Bottom.setPower(.6);
                robot.Right_Top.setPower(.6);
            } while(gamepad1.left_stick_x == -1 && gamepad1.left_stick_y == 1){
                robot.Right_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Bottom.setPower(-.6);
                robot.Right_Top.setPower(-.6);
            } while (gamepad1.right_stick_x == 1){
                robot.Right_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Right_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Right_Top.setPower(.6);
                robot.Right_Bottom.setPower(-.6);
                robot.Left_Bottom.setPower(.6);
                robot.Left_Top.setPower(-.6);
            } while (gamepad1.left_stick_x == -1){
                robot.Right_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Right_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Bottom.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Left_Top.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                robot.Right_Top.setPower(-.9);
                robot.Right_Bottom.setPower(.3);
                robot.Left_Bottom.setPower(-.3);
                robot.Left_Top.setPower(.9);
            }

            if (gamepad1.a) {
                robot.Lift.setPower(-1);
            } else if (gamepad1.y){
                robot.Lift.setPower(1);
            } else if (gamepad1.right_trigger == 1){
                robot.Lift.setPower(0);
            }

            if (gamepad1.b) {
                robot.Elbow.setPower(.5);
            } else if (gamepad1.x) {
                robot.Elbow.setPower(-.5);
            } else if (gamepad1.left_trigger == 1) {
                robot.Elbow.setPower(.55);
            }

            if (gamepad1.right_bumper) {
                robot.Intake.setPower(.5);
            } else if (gamepad1.left_bumper) {
                robot.Intake.setPower(-.5);
            } else if (gamepad1.dpad_right) {
                robot.Intake.setPower(0);
            }

            if (gamepad1.dpad_up) {
                robot.Shoulder.setPower(.5);
            } else if (gamepad1.dpad_down) {
                robot.Shoulder.setPower(-.5);
            } else if (gamepad1.dpad_left){
                robot.Shoulder.setPower(0);
            }
        }
    }

}