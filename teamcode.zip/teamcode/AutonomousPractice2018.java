package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
@Disabled
public class AutonomousPractice2018 extends LinearOpMode
{

    public void runOpMode()throws InterruptedException{

    }

}
